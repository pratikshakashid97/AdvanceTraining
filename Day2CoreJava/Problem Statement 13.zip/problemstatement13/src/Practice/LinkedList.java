package Practice;

public class LinkedList {

}
